# Handoff: Koyeba front-end redesign

Koyeba is the new name for Shizu (before that Daybook and Lifebook). Repo: `robskils/today-robski`. New domain: **koyeba.co**.

**Read this whole file before touching any UI code.** The design is deliberately restrained, and most of its quality comes from what it leaves out. If a change you're about to make adds a box, a shadow, a pill, a colour, an icon or a rounded corner, it is almost certainly wrong.

---

## 1. About these files

`Koyeba App.dc.html` and `Koyeba Logo.dc.html` are **design references built in HTML**. They are working prototypes of the intended look and behaviour, not production code.

- **Your task:** rebuild these designs inside the existing app (`public/*.html`, `public/*.js`, `public/*.css`, worker API), using its existing data and endpoints.
- **Don't** paste the prototype in, and don't load `support.js` in production.
- **Fidelity: high.** Colours, type, spacing, copy and interactions are final. Match them exactly.
- **To view:** open either `.dc.html` file in a browser, served from this folder so the fonts and assets load.
- **Tweaks:** the prototype has two props, `navigation` (`Folds` | `Index`) and `night`. Robin's default is **Folds**.
- **Not covered:** everything visual in the current app is replaced. The worker, data model, auth, sync and APIs are **unchanged**; this is a front-end job.

---

## 2. Non-negotiables (do not "improve" these)

1. **One accent colour: gold.** No red, green, blue, orange or purple anywhere, including for urgency, errors or status. Urgency is shown with a **filled gold square**, lesser states with an **outlined gold square** or a **grey square**. The only exception is a genuine destructive error.
2. **Square corners everywhere.** `border-radius: 0` on cards, buttons, inputs, chips, avatars and tiles. No pills.
3. **No shadows on cards or panels.** The only shadow in the app is on the capture drawer (`0 -18px 50px rgba(30,25,10,.10)`). There is no glassmorphism and no blur.
4. **1px warm keylines** separate things. Never thick borders, and never a coloured left-border "accent stripe".
5. **No sidebar of buttons.** Navigation is folding sections (Folds) or a top row that unfolds a panel (Index). See §5.
6. **Every titled section folds open and shut**, using a `+` / `−` glyph on the right. Nothing uses chevron icons.
7. **No full-width buttons.** Buttons are small: uppercase Jost, 11px, 0.22–0.24em tracking, padding `11px 22px`. The primary button is solid gold with forest-ink text; the secondary has a 1px keyline.
8. **Large, legible text** (Robin's eyesight). Body text is never below 13px, and list items are 15–17px.
9. **No icon fonts and no emoji.** The only glyphs used are `+ − → ✓ ✕ ⌘ · ‹ › ▶ ▼ ⌄`.
10. **Cormorant Garamond 300 for anything that speaks** (headings, names, numbers, quotes). **Jost for anything that labels** (UI text, metadata, buttons, eyebrows).
11. **Connections between items stay subtle:** an italic Cormorant sentence, a small gold dot, a Roman numeral. Never arrows, lines or "linked" badges.
12. **Night mode is a deep forest green, never blue-grey and never black.**
13. **Voice:** calm, warm, British English, short sentences, no hype, no exclamation marks, no emoji. Say "Set something down…", not "Quick add". Say "Not yet", not "Snooze". Say "12 days past", not "OVERDUE".

---

## 3. Design tokens

All colours are given in OKLCH (as used in the prototype), with hex approximations.

### Day (default)
| Token | OKLCH | ≈ Hex | Use |
|---|---|---|---|
| `--k-bg` | `oklch(0.975 0.012 85)` | `#f8f4ec` | Page (ivory) |
| `--k-panel` | `oklch(0.99 0.006 85)` | `#fdfbf7` | Cards, drawer, inputs-in-panels |
| `--k-soft` | `oklch(0.94 0.016 82)` | `#efe9dc` | Selected row, inner dividers, open sheet |
| `--k-ink` | `oklch(0.22 0.018 60)` | `#2a2620` | Text |
| `--k-mute` | `oklch(0.46 0.022 70)` | `#6b6357` | Secondary text |
| `--k-line` | `oklch(0.88 0.014 80)` | `#e0d9cc` | 1px keylines |
| `--k-gold` | `oklch(0.72 0.13 75)` | `#c99a3e` | Accent fills, rules, markers |
| `--k-goldt` | `oklch(0.55 0.11 70)` | `#8f6c2a` | Gold **text** (passes contrast on ivory) |
| `--k-deep` | `oklch(0.28 0.04 155)` | `#2c4a3a` | Forest: capture bar, notification, avatars |
| `--k-ondeep` | `oklch(0.975 0.012 85)` | `#f8f4ec` | Text on forest |

### Night (`body.night`)
| Token | OKLCH |
|---|---|
| `--k-bg` | `oklch(0.23 0.035 158)` |
| `--k-panel` | `oklch(0.26 0.035 158)` |
| `--k-soft` | `oklch(0.29 0.035 158)` |
| `--k-ink` | `oklch(0.94 0.012 85)` |
| `--k-mute` | `oklch(0.74 0.02 80)` |
| `--k-line` | `oklch(0.36 0.03 158)` |
| `--k-gold` | `oklch(0.74 0.12 76)` |
| `--k-goldt` | `oklch(0.80 0.11 78)` |
| `--k-deep` | `oklch(0.18 0.035 158)` |

Text on a solid gold button is always `oklch(0.22 0.018 60)`, in both day and night.

### Type
Fonts are self-hosted in `fonts/` (latin woff2): Cormorant Garamond 300, 300 italic and 500; Jost 400, 500 and 600.

| Role | Spec |
|---|---|
| Greeting (Today) | Cormorant 300, 70px / 1.02, two lines. The name is *italic gold*; the second line is muted |
| Space title | Cormorant 300, 84px / 1, with an italic gold Roman numeral at 36px before it |
| Screen title (Mail, Calendar…) | Cormorant 300, 44–56px |
| Section heading (folds) | Cormorant 300, 30px; hint in Jost 14px muted; `+`/`−` in Jost 300 18px muted |
| Item / list title | Cormorant 300, 23–26px |
| Big numbers (ledger) | Cormorant 300, 40–46px |
| Reading subject | Cormorant 300, 44px / 1.1 |
| Capture input | Cormorant 300, 38px, bottom keyline in ink |
| Body / list rows | Jost 400, 15–17px, line-height 1.4–1.7 |
| Meta | Jost 400, 12.5–14px, muted |
| Eyebrow | Jost 500, 11px, `letter-spacing: .28em`, uppercase, gold text, preceded by a 28×1px gold rule with a 12px gap |
| Field label | Jost 600, 10px, `.2em`, uppercase, muted |
| Button | Jost 500, 11px, `.22–.24em`, uppercase |
| Space numeral | Cormorant 300 italic, 15–17px, `--k-goldt` (I, II, III, IV, V) |
| Logo wordmark | Cormorant 500, 28–32px, "Koyeba" followed by a gold "." |

### Spacing and shape
- **Page padding:** `52px clamp(24px,4vw,64px) 160px`. The 160px bottom leaves room for the capture bar.
- **Content max-width:** 1220px.
- **Rows:** 10–18px vertical padding, separated by 1px `--k-line`; inner rows use `--k-soft`.
- **Cards** (Space page only): `--k-panel` background, 1px `--k-line` border, padding `22px 26px`, header underlined by a **1px gold** rule.
- **Radius:** 0. **Shadows:** none (except the drawer).
- **Markers:** 6–8px squares. Filled gold means it needs you or is urgent; outlined gold means important; grey means lesser.
- **Motion:** `fadeUp` 8px over 0.4–0.5s `cubic-bezier(0.2,0.7,0.2,1)` when something unfolds. The drawer slides 0.6s on the same curve. Colour transitions take 0.4s ease. No bounces, no springs.

---

## 4. Layout shell

```
┌──────────┬────────────────────────────────────────────┐
│  Folds   │  Screen (scrolls)                          │
│  nav     │                                            │
│  clamp   │                                            │
│ (210px,  │                                            │
│  21vw,   │                                            │
│  280px)  │                                            │
│          │          [ + Set something down…  ⌘ . ]    │ ← floating forest bar
└──────────┴────────────────────────────────────────────┘
```
- Full viewport height; only the screen area scrolls.
- The capture bar sits at the bottom centre, 460px wide, 24px from the bottom. It is forest green, with a gold `+` and italic Cormorant placeholder text. Clicking it, or pressing ⌘., opens the drawer.
- Responsive: every two-pane screen uses `clamp()` widths for its list column. Grids use `repeat(auto-fit, minmax(min(100%, Npx), 1fr))`. It must work at around 920px wide.

---

## 5. Navigation (replaces the old sidebar)

The 35 sidebar buttons are regrouped into **seven folds**, and only one is open at a time:

| Fold | Closed hint (live) | Items |
|---|---|---|
| Today | "Friday · two still to tick" | Home, Flow, Practices |
| Spaces | "Five · one shared" | each Space, with its Roman numeral |
| Tools | "Mail N to sort · Tasks 4" | Mail (badge = inbox count), Calendar, Tasks, Notes, Tables, Goals, Saved, Discover |
| People | "N new messages" or "Mum is due a call" | Contacts, Messages (badge = unread), Connect |
| Money | "€1,240 in October" | Spending, Money, Portfolio, Advice |
| Inner life | today's I Ching | Reflection, Journal, Coaching, Dreams, Compass, I Ching, Spirit Cards, Horoscope, Insights |
| Reviews | "Weekly, on Sunday" | Daily, Weekly, Monthly, Quarterly, Yearly |

- **Folds nav (default):** the left column holds the logo, then "Find… ⌘K", then the folds. The open fold lists its items in Jost 16px. The current screen's fold title and item turn gold-text. At the bottom are text links: Night · Settings · Guide · Welcome. Admin and Sign out go in Settings, not the nav.
- **Index nav (alternative):** the seven fold names run across the top. Clicking one unfolds a full-width `--k-soft` sheet of its items, each with a one-line description. "Fold away ✕" or Esc closes it.
- **"Life Spaces" are now just "Spaces"** everywhere.

---

## 6. Screens

### 6.1 Today (home)
1. **Eyebrow:** "Friday · an overcast evening" (day, weather word and part of the day).
2. **Greeting:** "Good evening, *Robin.*" then, muted, "The day is drawing in."
3. **Ledger:** four numbers in a row: emails to sort, things to do today, events tomorrow, spent this month. Clicking one unfolds its rows beneath the ledger, with a gold underline on the active number and an "Open Mail →" style link. Only one is open at a time.
4. **Two columns** (auto-fit, min 320px):
   - **Left, Today:** a timeline. Each row is the time (Jost 500 13px muted), a 7px gold-outlined square on a 1px vertical line, then the title (17px), with the Space numeral and name plus a meta line beneath, and a tick box (18px square) on the right. A ticked item's square fills gold and the row drops to 55% opacity. The timeline ends with a gold "22:04" marker and the italic line "Now. The rest of the evening is yours." Below it, **Your spaces** is shown as tiles: numeral and name, a one-line status, a 2px progress line, and a footnote.
   - **Right, Coming into view** (this is "My Shizu", renamed; keep this name). Its groups each fold away:
     - **Messages** (only when there are unread messages): `Name: last message`.
     - **Deadlines:** Spaces that have a deadline. Due text: "12 days past" (filled gold, gold text), "Tomorrow" (outlined), "In 7 days" (grey).
     - **Do next:** P1 and next tasks. The count shows 12, it is **folded by default**, and it ends with "And 9 more in Tasks →".
     - **Back today:** snoozed tasks whose date has arrived.
     - **Keep in touch:** people on a cadence. Ticking rolls the date forward from today.
     Then come **A line for the evening** (I Ching: the character, *name*, "I Ching · changing", one-line reading) and the **Notepad** (a plain textarea, no box).
5. **Foot mark:** the Mandombe "koyeba" at the bottom, centred, 240px wide, at 55% opacity rising to 100% on hover, with "KOYEBA · TO KNOW" beneath. **Clicking it scrolls to the top**, the same as clicking the wordmark.

Data: `/api/day`, plus the brief (`worker/brief.js`), plus `surfaced`, `keepInTouch` and `open_p1` from `worker/index.js`.

### 6.2 Space (e.g. The kids)
- "← Today", then the numeral and the title (84px).
- A meta row: the status line; if the Space is shared, square avatars (forest and gold, 28px, overlapping by 8px) with "Shared with Joana — she sees only this space"; on the right, the gold text links "Share" and "Give it a deadline".
- A ledger of four stats between keylines.
- **Cards** (auto-fit, min 340px) for Tasks, Calendar, Mail, Notes, Money and People. Each folds and has "+ Add" at the bottom.
- A Space with a deadline counts down. This is the same model as a project (see the brand note).

### 6.3 Mail — Robin's actual triage model
**Left column** (`clamp(280px,34%,420px)`): "Mail" with "+ Compose" in gold text, then "All accounts · N unread ⌄". The **piles** are folding rows, each with a marker, name, hint and count:

| Pile | Hint | Marker |
|---|---|---|
| Inbox | To sort | grey outline |
| Urgent | Important and timely | **filled gold**, gold count |
| Important | Important, not rushed | gold outline |
| Read later | Worth a read, no rush | grey fill |
| Archive | Done | keyline |

Below the piles, a folded **Folders** row holds Drafts, Sent, Spam and Trash. The open pile lists its messages: unread dot, sender, subject, snippet, time and Space numeral. An empty Inbox shows, in italic, "Inbox clear. Nothing left to sort." Piles with more history show "and N earlier".

**Reading pane:**
- Eyebrow: "II The kids · Thu · Inbox".
- Subject (44px Cormorant), then "From Name · address".
- **Sort row**, between keylines: `SORT  ■ Urgent 1  □ Important 2  ▪ Read later 3  — Archive 4`. The current pile is gold-underlined.
- **Turn into row:** Note · Task · Event.
- **Dates found** (only when the email contains dates): a `--k-panel` box with a 1px gold left keyline (the one place this is allowed, because it is the same weight as the other edges). It shows the eyebrow "DATES FOUND", the event name (Cormorant 23px) and the date, with "Add to calendar →", which becomes "Added ✓" once used.
- Body (Jost 16.5px / 1.7, max 640px), then Reply (gold) and Forward (keyline).
- If the email is already linked to something, an italic Cormorant line says so, e.g. "Already a task: Book booster jab · due today."

**Behaviour:** keys **1–4** sort the open email (only when focus isn't in a field). Sorting from the Inbox auto-selects the next Inbox email and shows a toast: "Moved to Urgent. 4 left to sort." The Inbox count, the Tools fold hint and the Mail badge all update live.

Data: `worker/mail.js` (`move`, `move-bulk`, `flag`, `messages`, `cached`, `unread`).

### 6.4 Calendar
- Header row (no wrapping): "Calendar", a **Day by day | Month** toggle (gold underline), muted "Search · From a file" (ellipsis when tight), and **+ Event** (gold button) on the right.
- **Day by day:** each day is a row with the date (Cormorant 48px) and label on the left and its events on the right (time · title · where · Space). Today's top rule is gold. An empty day says "Nothing yet. Just this."
- **Month:** a 7-column grid of 1px keyline cells; each event is a gold 5px square and its title.
- **New event** keeps every field from the current app but loses the boxes:
  - The title is a 36px Cormorant input on a bottom keyline, with the Space selector beside it.
  - From/to date and time, All day (square box) and Repeat.
  - Where, Remind me (multi-select: a dot with its label; several allowed; "+ Custom") and Note.
  - Connect, which folds out: a website, a contact, a note, an email.
  - Add to calendar (gold) and Close (text).

### 6.5 Tasks
Title "Things to do", then a summary line. The groups fold: **Today** · **Back today** (snoozes that have arrived) · **Keep in touch** (cadence) · **Resting** (snoozed, folded by default). Each row has a tick box, title, meta, and Space numeral and name. Clicking a title unfolds "Set aside: Tomorrow · Next week · Pick a day", the priority, and an italic link line.

### 6.6 Notes and tables
- **Left:** notes grouped by Space (folding), with a "TABLE" tag on notes that contain a table.
- **Right:** eyebrow, a **Note | Table** toggle, and the title (52px).
- Blocks:
  - **Toggle headings:** a gold ▶/▼, the heading in Cormorant 30px gold-text, and indented lines underneath.
  - **Paragraphs.**
  - **Inline tables:** a label, a top rule in ink, uppercase column heads, `--k-soft` row lines, and "+ Row · Sort · Total".
- Footer hint: "Type, or press / for a toggle, a table, a link…"
- **Note ⇄ Table** flips the same content into a table and back without loss (`public/notes.js`, `public/tables.js`).

### 6.7 Messages
- **Left:** threads, each with a square forest avatar showing initials, the name, Space numeral, last line, time and an unread gold square.
- **Right:** the thread. Bubbles are square with a 1px keyline: theirs on `--k-panel` on the left, yours on `--k-soft` on the right. Below is an input (24px Cormorant on an ink bottom rule) with "Send ↵", and then, in muted text, "Make it a task · Add to calendar · File to a space".
- **Incoming notification:** a forest card, top right, 360px. It shows a gold dot, the name, the Space numeral, "The kids · just now", the message in Cormorant 22px, and **Reply →** and **Later**. It hides as soon as that thread is read or open.

### 6.8 Reflection (inner life)
- Today's question in italic Cormorant 58px, then a textarea (`--k-panel`, keyline) and the links "Saved to Journal · File to a space · Ask Coaching about this →".
- Three folding columns: **This week** (a small bar chart; today in gold), **I Ching** history, and **Reviews**.

### 6.9 Money
- "€1,240" at 92px, with a one-sentence explanation.
- Bars by Space, 10px tall, gold, on a `--k-soft` track.
- "Filed themselves this week": the list of payments that were sorted automatically.

### 6.10 Search (⌘K)
A centred overlay, 760px, on a 35% ink scrim. A 38px Cormorant input. Results are grouped Spaces / Mail / Tasks / Calendar / Notes, each with its Space numeral. With an empty query it shows recent items. If nothing matches: "Nothing by that name yet." Esc closes it.

### 6.11 Capture: "Set it down" (⌘. or the bar)
A drawer slides up from the bottom (800px wide, `--k-panel`, top shadow only). It has the eyebrow "SET IT DOWN", the input "I've got the dentist on Tuesday at 9am", and "Esc · fold away".
- **Empty:** "Just write it as you'd say it. Try …" with three clickable examples.
- **While typing**, a live readout: "Koyeba reads this as — tap a line to change it". Its rows are **What** · **As** (tap to cycle Event, Task, Note, Spend) · **When** · **Into** (tap to cycle Spaces; shows "guessed from 'dentist'") · **Remind** (with a one-line reason).
- **Parsing is rule-based, not AI** (the brand promise is that it works without AI):
  - Strip lead-ins ("I've got", "remind me to"…). Normalise curly apostrophes first.
  - Day: today, tomorrow and weekdays; "next" adds 7 days. Time: 9am, 9:30, 14:00, "at ten", noon. A bare hour below 8 is taken as pm.
  - Type: € or "spent" means Spend; "remind/need to/buy/call/book/pay/send/order" with no time means Task; a day or time means Event; anything else is a Note.
  - Space: keyword lists (vet/Biscuit → the dog; Ada/Tom/school → kids; boxes/keys/Remax → the move; Priya/Geeza/proposal → work; dentist/doctor/Mum/zazen → Body & mind). In production, learn these from each Space's own words.
  - Reminders: an appointment (dentist, doctor, vet, flight…) gets **"The evening before, 20:00" plus "1 hour before"**; a timed event gets 30 minutes before; an all-day event gets 09:00 on the day; a task with a day gets 09:00 on that day.
- **Set down ↵** files it and shows a toast, e.g. "Dentist — Tue 3 Nov at 09:00. I'll remind you the evening before, 20:00 and 1 hour before."

### 6.11b Voice capture: "Speak"
- **Entry points:** a **Speak** button at the right of the capture input (a keyline button, gold 7px square, uppercase Jost 11px), and a small **Speak** on the floating capture bar, which opens the drawer and starts recording straight away.
- **While recording, the input is replaced by:**
  - Italic Cormorant 34px reading "Listening…", which changes to "Heard" once words arrive.
  - A row of 48 thin gold bars (3px wide, 3px gap) whose heights follow the live mic level.
  - The timer `0:07` (tabular numerals).
  - A forest **Done** button.
  - The bottom rule turns gold.
  - Interim words appear underneath in Cormorant 24px as they're heard.
- **On Done**, or when speech ends, the transcript goes into the input and through **the same parser and readout as typed text** (§6.11). The user can correct it before pressing Set down. Esc cancels.
- **Footer copy while voice is used:** "Your voice is transcribed, then the recording is discarded."
- **Transcription (Claude cannot transcribe audio), in order of preference:**
  1. **Cloudflare Workers AI, Whisper** (`@cf/openai/whisper` or `whisper-large-v3-turbo`). It runs on the same Cloudflare account as the worker, so no third party holds the audio. Record with `MediaRecorder` (webm/opus), POST to `/api/transcribe`, return the text.
  2. **Gemini** (audio input) as an alternative, if Whisper's quality isn't good enough for Robin's accents and languages (English and Portuguese).
  3. **Browser Web Speech API** as an instant fallback. On Safari/iOS it can run on the device; on Chrome, audio goes to Google, so say so in settings.
- **Privacy:** following the brand rule that every AI use has its own switch, put a "Voice capture" toggle in Settings. Never store the audio. Never send anything without the user pressing Speak.
- **Prototype behaviour:** the prototype uses the browser's Web Speech API if one is available (en-GB). Otherwise it types out a demo phrase.

### 6.12 Welcome (onboarding, 4 steps)
A progress row of 1px segments.
1. The Mandombe mark, then "NASEPELI KOYEBA YO" / "Pleased to know you." / a name input.
2. "The parts of your life." Choose starter Spaces (the `DEFAULT_STARTERS` in `worker/accounts.js`).
3. "Bring your tools in." Google, IMAP, iCloud or Fastmail (CalDAV), Notion or Tana.
4. "Share a space, if you like."

### 6.13 Placeholders
These were not designed in this pass: Goals, Contacts, Dreams, Compass, Coaching, Spirit Cards, Horoscope, Insights, Reviews detail, Flow, Practices, Saved, Discover, Portfolio, Advice, Tables index. **Build them from the same parts:** folding sections, a ledger of Cormorant numbers, keyline rows, Space numerals, gold only where something needs you. **Don't invent new visual elements.**

---

## 7. Logo and brand

- **The primary logo is the wordmark:** "Koyeba" in Cormorant Garamond 500, with a gold full stop.
- **Mandombe** (the script) spells *ko-ye-ba*. Its vowel strokes are gold (red in the source, recoloured). See `Koyeba Logo.dc.html` for the uses:
  - **2a/2b:** the full lockup (script, a short gold rule, the wordmark, "TO KNOW"), for the website, print and the welcome screen.
  - **2c:** the app icon. **Just "ko"** on a gold tile (`assets/mandombe-ko-tile-gold.svg`) or a forest tile (night). Use it for the favicon and apple-touch and 192/512 icons, replacing all the `public/icon-*.png` and `apple-touch-icon*.png` files.
  - **2d:** the header. A small "ko" mark (26–28px tall) sits before the wordmark and **replaces the 静 character everywhere**.
  - **2f:** the welcome screen.
  - **Today:** the full word at the foot of the page (see 6.1). **Not** behind the greeting; Robin tried that and it was too busy.
- ⚠️ The strokes were traced by eye from a screenshot. **Have a Mandombe reader verify them** before public launch.
- The meaning of Koyeba is "to know" in Lingala. *Nasepeli koyeba yo* means "pleased to know you".

### Assets (`assets/`)
| File | Use |
|---|---|
| `mandombe-koyeba-ink.svg` / `-ivory.svg` | Full word, day/night, with gold vowels |
| `mandombe-koyeba-ink-mono.svg` | Single-colour full word |
| `mandombe-ko-ink.svg` / `-ivory.svg` | "ko" for the header |
| `mandombe-ko-tile-gold.svg` / `-tile-forest.svg` | App icon and favicon |
| `mandombe-koyeba-soft*.svg`, `-faint*.svg` | Low-opacity versions (spare) |

---

## 8. Rename and domain move (Shizu → Koyeba, shizu.fyi → koyeba.co)

- **Copy:** replace every user-facing "Shizu", "Daybook" and "Lifebook" with **Koyeba**. That includes `public/*.html`, `/blog`, and the `pt/`, `fr/`, `es/`, `de/` and `it/` pages and their journal posts, `i18n.js`, the invite and OTP emails (`worker/invite-email.js`, `worker/auth.js`), push notifications, and `robots`/`sitemap` in `worker/index.js`.
- "My Shizu" becomes **"Coming into view"**; "Life Spaces" becomes **"Spaces"**; the brand mark 静 becomes the Mandombe "ko".
- **`wrangler.toml`:** add the koyeba.co routes and custom domain, and update the `FROM_EMAIL` brand name. Check `ADMIN_EMAILS`.
- **Google OAuth:** add koyeba.co to the authorised origins and redirects.
- **SEO:** update `canonical`, `hreflang`, `og:url` and `og:image`, then add **301 redirects from shizu.fyi/* to koyeba.co/*** (same path).
- **localStorage keys** (e.g. `daybook.consent`): **leave them alone**, or migrate them, so users aren't signed out or re-prompted.
- **Manifest and theme colour:** set `theme-color` to forest (`#2c4a3a`) instead of `#111327` navy.

---

## 9. Suggested order for Claude Code

1. Put the tokens (§3) into one CSS file with day and night variables, and remove the old navy theme.
2. Replace the shell and navigation (§4–5).
3. Today (§6.1), then Mail (§6.3), then Capture (§6.11). These carry the most of the product's feel.
4. Calendar, Tasks, Notes, Space and Messages.
5. Brand assets and the rename and domain work (§7–8).
6. Placeholders (§6.13), built from the same parts.
7. The public homepage (§10).
8. The Space page (§11).
9. The Mail page (§12).
10. The Goals page (§13).
11. Night mode, across everything (§14).
12. Smart Set something down (§15).
13. What next (§16).
14. Navigation: groups, top line, contents, mobile, and Find with Recent / Shared (§17).
15. Side by side (§18).
16. Using the whole screen: responsive grid (§19).
17. Notepad popover (§20).
18. Notes, Tasks and Reflection (§21–23), and the Money group (§17).

**After each step, compare it side by side with `Koyeba App.dc.html`.** If they differ, the prototype is right.

---

## 10. Public website (koyeba.co homepage)

Reference: `Koyeba Website.dc.html`. It replaces the current homepage (`public/index.html` and its `pt/ fr/ es/ it/ de/` versions). It uses the **same tokens, type and rules as the app** (§2–3). Keep everything in the current `<head>` (SEO, hreflang, Open Graph, JSON-LD, the `today.token` redirect, cookie consent, sign-in modal, invite form handling); only the visible page changes.

**Fix in the copy across all languages:** spaced hyphens " - " become en dashes " – ". Remove "Sintra" and any other travel leftovers.

### Sections, in order
1. **Header:** the Mandombe "ko" (26px) and the wordmark, with links The idea · Tools · Privacy · Journal, then "Sign in" (text) and "Request an invite" (gold button). No wrapping: everything is `white-space: nowrap`. Move the language picker to the footer if the header gets tight.
2. **Hero:** eyebrow "Invite-only · early access", headline "Set it down. *It comes back* when you need it." (Cormorant 300, up to 86px), one-sentence lead, "Request an invite" (ink button) and "How it works →".
   - **On the right, a live demo of the capture drawer** (§6.11): a phrase types itself out, then the readout rows (Into · As · Reminds/Joins) fade up 8px. It cycles three examples: the dentist on Tuesday at nine, Ada's trip form, Biscuit's flea drops for €18.40. Respect `prefers-reduced-motion` by showing the first example still.
3. **The idea:** "We carry too much at once." and two short paragraphs, including "Koyeba is Lingala for *to know*".
4. **Tools:** "Everything you use, *talking to each other.*" **No icons and no grid of tiles.** Two columns of folding rows: **For the doing** (Mail, Calendar, Tasks, Notes, Messaging, Money, Contacts) and **For the inner life** (Journal, Reflection, Reviews, Goals, Coaching, Read & Watch, Bucket list). Each row has the name (Cormorant 28px), a one-line description and `+`/`−`. Opening it shows a sentence, then "Joins …" in gold text. One open at a time; Mail is open by default. Robin should check these descriptions.
5. **Spaces** (forest panel): copy on the left, with a folding "Share a Space with the people in it". On the right, a sample Space, "II The kids", whose Mail/Tasks/Calendar/Notes groups fold.
6. **The inner life:** centred, a short paragraph, "Read more +" unfolds the rest.
7. **Private by design:** "Yours. *Properly.*" Five folding points numbered I–V. **No ticks.**
8. **Made to be quick:** three columns, I · II · III.
9. **Invite** (night-forest panel): the full Mandombe word in ivory, "Come and set it down.", an email field on a single keyline with a gold "Request an invite" button, and "I already have an account".
10. **Footer:** wordmark and "For a life well lived", links, "Feito em Lisboa · © 2026 Koyeba". Then the **foot mark**: the full Mandombe word, 240px, 50% opacity rising to 100% on hover; clicking it scrolls to the top. Beneath it, the **dictionary entry**:
    - Line 1: **Koyeba** (Cormorant 500, 24px) · koh-YEH-bah (Jost 14px, muted) · *verb, Lingala* (Cormorant italic 18px, gold text)
    - Line 2: "To know – facts, places, people." (Cormorant 300, 20px, muted)
    - Translate line 2 in each language version, but keep the pronunciation as it is.

### Rules specific to the site
- Content max-width 1240px; section padding `clamp(64px,8vw,112px)` top and bottom. Two-column sections use `repeat(auto-fit, minmax(min(100%, 420–460px), 1fr))` so they stack on narrow screens.
- "Set it down" appears only in the hero and the invite. Don't add it anywhere else.
- No icons, no ticks, no tile grids, no shadows, square corners. The same non-negotiables as the app.

---

## 11. Space page (e.g. "Art")

Reference: `Koyeba Space.dc.html`. It **replaces the current Space page entirely**: no metric tiles, no icon tiles, no left column of tool cards, no activity box. Use the same tokens, type and non-negotiables as §2–3, and keep night mode.

### Structure, top to bottom
1. **App header:** the Mandombe "ko" with the wordmark, a breadcrumb "Spaces / Art" (Spaces in muted text), Find anything ⌘K, and Night/Day.
2. **Cover:** the Space's cover image, full content width, `clamp(180px,22vw,300px)` tall, `object-fit:cover`, square corners. It's optional; hide it if the Space has none.
3. **Title block:** an eyebrow "Space · III of 34" with a gold keyline; the Space name in Cormorant 300 at `clamp(80px,9vw,128px)`; the vision as one italic line beneath it.
   - On the right: member initials (36px squares on forest), a dashed + to invite, "Kept close" (a gold square toggle that replaces the star), "+ Add to this Space" (gold button) and ··· for the menu.
4. **Contents line:** between an ink rule above and a keyline below, a quiet run of counts, e.g. "3 goals · 48 tasks · 23 notes · 4 tables · 2 events · 24 emails · 9 files · 2 people · 1 book". The number is Cormorant 24, the word is Jost 14 muted. **Clicking a count opens that section and scrolls to it.**
   - "Search this Space" sits on the same line, as an underline input. Typing filters every section and opens the ones that have matches.
5. **Two columns:** `minmax(0,1fr)` and `minmax(260px,340px)`.
   - **Main column:** "Open all · Fold all" above a stack of folding sections, numbered I–IX: Vision & goals, Tasks, Notes, Tables, Calendar, Emails, Files, Contacts, Books & films.
     - **Header row:** the numeral (Cormorant italic, gold), the title (Cormorant 300, 30–38px), the count (Jost 13 muted), **a one-line hint when closed** (e.g. "Today: do a watercolour painting"), and +/−.
     - **When open:** the content is indented 48px and fades up 8px. Rows are separated by keylines, and each section ends with "All 23 notes →" (gold text) and "+ New note" (muted).
     - **Vision & goals:** the vision sits in a forest panel. Each goal has a thin gold progress line ("2 of 5 steps"), then a "One day" line for the bucket list.
     - **Tasks:** a 13px square checkbox that fills gold when ticked, with strikethrough. Done count lives in the header: "48 · 3 done this week".
     - Vision & goals and Tasks start open; the rest start folded. Remember each user's choice per Space.
   - **Side column (sticky):** three folding panels, each with an ink rule on top and a Jost uppercase label.
     - **Coming into view:** the next few dated things, each with a quiet gold "where it came from" line.
     - **Lately:** recent activity in plain sentences ("You updated the page Watercolour."), ending with "See all 40 →".
     - **In this Space:** the members, ending with "+ Invite someone".
6. **Foot:** the full Mandombe word, 200px, 45% opacity rising to 100% on hover; clicking it goes back to the top.

### Don't
- No icons, emoji or coloured status squares.
- No separate "Done" metric.
- No boxed tiles.
- No red goal icons.
- Don't truncate titles in narrow boxes. Rows run the full width, so text never wraps word by word.

---

## 12. Mail page

Reference: `Koyeba Mail.dc.html`. It **replaces the current Mail page layout**: no coloured pile tiles, no boxed folder buttons, no letter avatars, no boxed account chips. Use the same tokens, type and non-negotiables as §2–3, and keep night mode. The same header and title block as the Space page (§11).

### Structure
1. **Title block:** an eyebrow "Tool · Mail", or "Mail · Urgent" etc. when a pile is selected. Then "Mail" in Cormorant 300 at `clamp(72px,8vw,112px)`.
   - Below it, **one italic line that changes as you go**:
     - "Eight to sort. Clear them in one pass." → "One left to sort." → "All sorted. Deal with the urgent ones first."
     - In other piles, the pile's description.
   - On the right: an account switch (an underline dropdown: All accounts / each address with its count / "Manage accounts →"), "Guide" as plain text, and a gold "Write" button.
2. **Piles row:** To sort · Urgent · Important · Later · Archive. Each is a Cormorant 40px number, a Jost 16 word and a 12.5px muted description (e.g. "Today, or it's late").
   - The selected pile is ink with a 1px gold underline sitting on the keyline; the others are muted. **No colour coding per pile.**
   - Drafts · Sent · Spam · Bin sit as quiet text links on the right of the same row.
   - **The counts must be live and agree everywhere.** The To sort count equals the italic line and the progress line.
3. **Two columns** (`minmax(0,1fr)` and `minmax(260px,330px)`):
   - **Main column:**
     - **Top:** an underline search input, and (in To sort only) a thin gold progress line with "3 of 8 sorted".
     - **Emails, grouped by day** ("This morning", "Yesterday", "Earlier this week"). Each group header is an uppercase label, a count, a keyline and +/−, and the whole group folds.
     - **Row:** the time (58px column) · sender in Cormorant 23 (500 if unread, 300 if read) · account as small muted text (only when "All accounts") · subject in Jost 16 · one muted preview line, truncated · a 6px gold square if Koyeba noticed something · +/−.
     - **Clicking a row unfolds it in place** (accordion, one at a time, panel background, fades up 8px). It shows:
       - The body.
       - When something was spotted, a **Noticed** line between keylines: a gold uppercase label, an italic Cormorant sentence ("A six-week group, Mondays at seven, from 16 November.") and one action ("Add to calendar →"), which becomes "Done".
       - The action row:
         - In To sort only, **sort buttons**: Urgent (ink outline) · Important · Later · Archive (keyline outline), each with its key hint U / I / L / A.
         - Then "Make a task · Make a note · Add event".
         - Then Reply · Forward on the right.
     - **Sorting:** the email leaves To sort, **the next one opens automatically**, and the counts update. A quiet "Moved to Urgent. Undo" appears above the list.
     - **Keys U / I / L / A** sort the open email (except while typing in an input).
     - In a pile, newly sorted mail appears at the top under "Just sorted".
     - **Empty To sort:** "Nothing left to sort." / "Start with Urgent – it's waiting for you."
   - **Side column (sticky):** folding panels, as on the Space page.
     - **Noticed in your mail:** every spotted date, payment or deadline with its action.
     - **Waiting on a reply:** sent mail with no answer, each with "Nudge".
     - Below them, a muted keyboard hint.
4. The **Set something down** bar floats at the bottom, as everywhere else.

### Don't
- No red/orange/green/blue pile colours.
- No icons on folders.
- No letter avatars.
- No grey boxes around email addresses.
- No square checkbox per row; sorting replaces selection.

---

## 13. Goals page

Reference: `Koyeba Goals.dc.html`. It **replaces the current Goals page**: no coloured left bars, no boxed goal cards, no "ACTIVE" chips, no × buttons, no boxed view tabs or sort dropdown. Same header and title block as the Mail page (§12).

- **Title block:** "Goals" plus one italic line built from live data, e.g. "13 goals across 8 Spaces. Five are nearly there."
  - On the right: a "Highlight the best bits" toggle (a gold square) and a gold "+ New goal" button.
- **Views row** (the same style as the Mail piles): By Space · Starred · All goals · Bucket list, each a Cormorant 40 count with a word and a hint.
  - Order sits on the right as text: Starred first · Closest to done · Recently touched.
- **By Space:** one folding row per Space (numeral, name, goal count).
  - **When closed:** one italic line of the vision, truncated, and **a tiny progress line per goal** (26px wide, with a 3px gold fill) at the right.
  - Open all · Fold all sit above the list.
  - **When open:**
    - The vision as italic Cormorant at 23–27px, max-width 720px.
    - With "best bits" on, each paragraph's best phrase stays ink on a faint gold wash (gold at 22% opacity) and the rest goes muted.
    - "Edit the vision" as text.
    - No vision: "Picture this part of your life at its best." and "Write a vision →".
    - Then goal rows: a 9px star square (filled gold when starred) · title in Cormorant 25 · meta "This quarter · 11 of 20 tasks · touched 3d ago" · a 150px progress line with %.
    - End with "+ Add a goal" and "Open Art →".
- **Starred / All goals:** flat rows (the same row style), with the Space name in gold text in the meta. All goals is grouped by This quarter / This year.
- **Bucket list:** a short italic intro, then a two-column numbered list (I, II…) in Cormorant 26, with no progress bars. Click to mark done (strikethrough).
- **Side column (sticky, folding):** "Nearly there" (60% or more, with %) and "Gone quiet" (untouched for 5 or more days).
- Only show a status label when a goal is **not** active (Paused, Done).

## 14. Night mode – fix across the whole app

Reference: `Koyeba Night Mode.dc.html`. It has the token table, the list of what's wrong in the current build, and a correct night Messages screen.

**The rule: no literal colours anywhere in components.** Every colour comes from the CSS variables in §2: `--k-bg --k-panel --k-soft --k-ink --k-mute --k-line --k-gold --k-goldt --k-deep --k-ondeep`. Night mode only swaps their values on `body.night`. Search the codebase for hex/rgb/oklch literals outside the token definitions and replace them all.

**Night values:**
- bg `oklch(0.23 0.035 158)`
- panel `oklch(0.26 0.035 158)`
- soft `oklch(0.29 0.035 158)`
- ink `oklch(0.94 0.012 85)`
- mute `oklch(0.74 0.02 80)`
- line `oklch(0.36 0.03 158)`
- gold `oklch(0.74 0.12 76)`
- goldt `oklch(0.8 0.11 78)`
- deep `oklch(0.18 0.035 158)`
- ondeep `oklch(0.94 0.012 85)`

**Fix specifically:**
1. Sidebar fold titles must use `--k-ink`. They're currently near-invisible. The open fold uses `--k-goldt`.
2. All keylines use `--k-line`. They're currently bright and heavy.
3. The Mandombe mark renders in the wrong colours at night. Keep the mark, and swap to `mandombe-ko-ivory.svg` on `body.night` (`mandombe-ko-ink.svg` by day).
4. A flat `--k-bg` ground. No gradients and no lighter inset panel behind the content.
5. Messages: plain rows on keylines, no boxed cards, no letter avatars. The unread marker is a 6px gold square.
6. The Set something down bar at night: `--k-deep` (darker than the page) with a 1px `--k-line` border.
7. Header: the breadcrumb is text, not a boxed back arrow and boxed "+ New".
8. Check every screen in both modes before calling it done: Today, a Space, Mail, Calendar, Tasks, Notes, Goals, Messages, Settings.

---

## 15. Smart "Set something down" (replaces the always-open bar)

Reference: `Koyeba Set Down.dc.html`. Click the tab or any example on the right.

**Folded by default.** The bar is no longer always open. At rest it's a small forest tab, bottom centre: "+ *Set something down* ⌘ ." (Cormorant italic 19, gold +).
- Click it or press **⌘ .** anywhere, and the drawer rises: translateY plus a fade, .55s `cubic-bezier(0.2,0.7,0.2,1)`, max-width 820px, `--k-deep` ground.
- **Esc** or "Fold away" closes it. The input is focused when it opens.

**It works out what you meant.** As you type, it picks one of **Task · Event · Note · Email · Money** and shows the choice as a row of words, with the chosen one underlined in gold.
- Beside it, one italic line says why, e.g. "Read as event – there's a day and a time".
- Tap another word, or press **Tab** / **Shift+Tab**, to change it. Once the user picks, show "You chose task".
- It also guesses the **Space** ("Into", with a Change link that cycles through Spaces).

What each type shows (label column 76px, uppercase 10px):
- **Task:** Into · Due · Reminds (on the due day at 08:30, or "In your Monday review" if there's no date).
- **Event:** Into · When · Reminds. Default reminders are the evening before and 45 minutes ahead (just the morning of if there's no time).
- **Email:** Into · To (matched from Contacts) · Subject (from "about …") · a starter Draft (editable). The button reads "Draft it". **It only ever creates a draft in Mail, and never sends.**
- **Money:** Into · Amount · On. Filed against the Space.
- **Note:** Into · Kept. Findable with ⌘K.

**After setting it down:** the drawer folds away, the item fades into Today, and a quiet confirmation appears above the tab: "Set down as a task in Art." with **Change** (reopens it with the text and choices intact) and **Undo**. It dismisses after 6 seconds.

**Intelligence:** the reference uses simple keyword rules only to show the behaviour. In the real build, use the user's own AI key (opt-in, as everywhere else) to classify, extract the date, time, recipient and Space, and draft the email. **Learn from corrections**: if they change a note to a task, weight that next time. Without AI, fall back to rules like the reference.

## 16. "What next" – one wise suggestion at a time

Same reference file, at the top of Today, and from the "What next?" button bottom-right (page ground, 1px gold border, Cormorant italic, gold text).

- **A block under the greeting**, between a gold rule above and a keyline below. It folds.
  - An eyebrow "What next" and a muted "one thing at a time" ("2 done ·" once some are done).
  - **One suggestion only**: a sentence in Cormorant 30–42px ("Sign Ada's trip form first."), then **one italic "because" line** in a calm, fatherly voice: short, warm, never nagging.
  - Then a gold button with a verb that fits ("Done it", "Write it", "Hold the hour", "Remind me at six"), plus **Not now** and **Something else** as text.
  - On the right, "Why this?" unfolds the joined dots: Email / Task / Calendar / Goal / Vision lines it used.
- **Each choice** fades the next suggestion in. When nothing is left: "That's enough for today." with a gentle line (e.g. take the dog out). It knows when to stop.
- **How to choose** (with the user's AI key; rules otherwise), roughly in this order:
  1. Things that will be late soon and are quick.
  2. Urgent mail.
  3. Commitments with a deadline today or tomorrow.
  4. A goal that's gone quiet, matched to free time in the calendar and tied back to their own vision words.
  5. People they meant to contact.
- Never more than one at a time. No scores, no streaks, no guilt.
- **Voice:** British English, plain, kind. Speak like someone who knows them: "This is what you said you wanted."

---

## 17. Navigation – new groups, top line, contents page, mobile

Reference: `Koyeba Navigation.dc.html` (2a desktop, 2b mobile). **This replaces the sidebar on desktop and the boxed icon drawer and icon tab bar on mobile.**

### The seven groups (the "Tools" group is gone)
1. **Spaces:** each Space.
2. **Conversations:** Mail · Messages · Contacts · Sharing.
3. **Plans:** Calendar · Tasks · Discover.
4. **Keep** (reference): Notes · Tables · Saved · Files · Read & Watch.
5. **The long game:** Goals · Bucket list · Reviews.
6. **Inner life:** Journal · Reflection · Coaching (and Practices, Insights if they exist).
7. **Money:** Spending · Bills · Accounts. **Optional.** It's always listed last. Nothing about money appears on Today, in What next or in hints unless the user has set Money up. Hints never show amounts ("Receipts, filed by Space", not "€46 this month").

**Today is not a group.** The wordmark takes you to Today. Don't give Today a tab, and don't make it the first item in a list.

### Desktop (2a)
- **Header:** the wordmark, then the seven group names (Jost 15, muted). The current group is ink, and the open group has a 1px gold underline sitting on the keyline. A gold count shows only where something waits (e.g. Conversations 8).
  - On the right: "Find ⌘K", and "Contents" (with a gold underline).
- **Clicking a group folds a sheet down** below the header, on `--k-soft` ground, fading up 8px. It shows the group name (Cormorant 34), a one-line description, "Fold away", then a grid of its tools.
  - Each tool is a numeral, a name in Cormorant 24, and **one live line** ("8 to sort", "Parkrun at nine").
  - Choosing a tool closes the sheet.
- **Contents (⌘/):** a full-page overlay under the header, with the seven groups in two columns numbered I–VII, each listing its tools. Esc closes it, and typing filters.

### Mobile (2b)
- **Top:** a small wordmark (to Today), with a breadcrumb or the date on the right.
- **Bottom: three things only**, on a keyline, at thumb height. **No icons and no five-tab bar.**
  - "Contents" (left, text).
  - **A 52px gold square "+"** (centre): Set something down.
  - "Find" (right, text).
- **Contents** opens full screen:
  - "Kept close" at the top: the user's pinned tools as Cormorant 24 words with counts. Press and hold any tool to pin it. **This replaces drag handles.**
  - Then the seven groups as folding rows: numeral, name in Cormorant 27, one hint line when closed. Tools open beneath as 44px+ rows, each with a hint.
- **Set something down on mobile** is a **bottom sheet**, not a floating bar:
  - It rises over a dimmed page, on forest ground, with a grab line at the top.
  - It holds the input (Cormorant 30), the type words (Event · Task · Note · Email) with the chosen one underlined in gold, the italic "Read as…" line, and the readout rows.
  - At the bottom: SPEAK, and a gold "Set down" button.
  - Same behaviour as §15. **Remove the full-width green bar on mobile.**

### No icons, anywhere
No ✉ ▤ ✓ ☺ ◐ ✳ glyphs, **no target/bullseye icon for goals**, no emoji in navigation. Words, numerals, counts and the single gold square only.

### Find holds Recent and Shared with you (V9)
- **The header stays:** wordmark · seven groups · Find ⌘K · Contents. Don't add Recent or Shared as header items.
- **Opening Find (click or ⌘K) shows, before any typing:** **Shared with you** first, with "3 new" when something is new, then **Recent**. Both are folding lists: a Cormorant 21 title, then a muted line with the type, Space or person, and when.
  - Typing replaces them with "Found" results from everywhere.
  - Desktop: a 520px panel under the header, right-aligned. Mobile: full screen from the Find text at the bottom right.
- **A gold count beside Find** shows only when something new has been shared, and clears when the panel is closed or an item is picked.
- **On Today:** one quiet line, only when something's new: a 6px gold square, "Joana added three things to The kids." and "See them" (it opens Find). Nothing shows otherwise.
- **Contents lists only the seven groups.**

### Plans absorbs The long game (V11) – six groups
- **The groups are now six:** Spaces · Conversations · **Plans** · Keep · Inner life · Money. **"The long game" no longer exists as a group.**
- **Plans** is "From today to one day". Its fold-down sheet has **three labelled rows**: **Soon** (Calendar · Tasks · Discover), **Further off** (Goals · Bucket list) and **Looking back** (Weekly review · Monthly review · Quarterly review · Year in review, plus any custom rhythm the user adds). Each row has an uppercase 10px muted label in a 110px column, then the tool grid.
- In Contents and on mobile, Plans lists all its tools in that order.
- **Every tool in a sheet shows a live hint line** ("Parkrun at nine", "Tonight"). Never leave one blank, or the names sit at different heights. If there's nothing live, use a quiet description.
- Update breadcrumbs: `Plans / Goals`, `Plans / Reviews`. The rule is now "six groups, seven at most".

### Money group (V14)
- **Tools:** Overview · Spending · Investments · Advice. Don't put a tool called "Money" inside Money; the overview is **Overview**.
- **Sheet strapline:** "What things cost, and what's growing". Before the user has set Money up, it reads "Optional – only if you want it".
- **Hints are words, never amounts:** "Where it all stands", "Filed by Space", "How they're doing", "Questions for a calm look".
- **Inside Money:** no red ▼ or green ▲ arrows. Show change as words in muted or gold text ("€240 less than last month").

### Night, Settings, Guide, Welcome
- **They aren't in the header.** They sit as **a quiet footer row at the bottom of Contents** (desktop and mobile): Night · Settings · Guide · Welcome in Jost 14, muted, on a keyline, with the person's name on the right.
- Night also keeps its keyboard shortcut and follows the system setting ("Auto") by default.
- "Welcome" reopens the onboarding.

### Rules for the top line
- **Six groups, seven at most.** New features go inside a group, never alongside one.
- **Below about 1100px wide,** collapse the group words. Show the wordmark, the breadcrumb ("Plans / Calendar"), Find and Contents. The contents page does the navigating.

---

## 18. Side by side – two panes

References: `Koyeba Side by Side.dc.html` (desktop) and `Koyeba Side by Side Mobile.dc.html`.

### Desktop
- **Two panes at most.** Opening a third replaces the older one. Shift-click anything, or use "Open beside…" (shown when only one pane is open), to open a second pane. It slides in from the right (.5s, fading in from 40px).
- **Pane header:** the group eyebrow and title (Cormorant 40). In the right pane: a pane switcher (e.g. Notes · Tasks), "Keep pair" with an 8px gold square ("Pair kept" when on), | and "Fold away".
- **Divider:** a 1px keyline with a 13px hit area. Drag it to resize (30–70%), and double-click it to reset to 50/50. It turns gold while you drag.
- **Drag to join the dots:** drag an email onto the right pane.
  - The pane shows a dashed gold outline and an italic hint ("Drop to make a note from Ana's email").
  - On drop, a **linked** note or task fades in at the top with "From Ana's email" in gold. The email row shows "note linked".
  - A forest confirmation with Undo appears, and dismisses after 5 seconds.
  - Without dragging: an open email offers "Make a note beside →" and "Make a task beside →".
- **Pairs:** "Keep pair" remembers the combination. "Open beside…" lists **Your pairs** first ("Mail with Notes – Most mornings").

### Mobile
- **One pane at a time.** When a pair is open, a 40px line under the status bar, with a gold keyline beneath, says "Notes is beside – tap to flip" or "Back to Mail". Tapping it slides between them (left/right, .45s); × ends the pair.
- **Long-press an email** to open a bottom sheet: Make a note beside · Make a task beside · Open Notes beside · Reply.
- After making something, a forest confirmation offers "See it", which flips to the other pane, where the new item sits at the top with its gold "From …" line.

## 19. Using the whole screen – responsive page grid (V10)

Reference: `Koyeba Wide Screens.dc.html` (1a 1280, 1b 1920, 1c 2560). **The current build pins content to a fixed column on the left. It looks accidental. Replace it on every page.**

### The grid
- **The header and the page share one container:** `max-width` + `margin: 0 auto` + side padding, so the wordmark lines up with the content.
- **Columns grow with the screen. Sections never stretch; they move between columns.** Use CSS grid with `grid-template-areas`:
  - **Under 900px:** 1 column. Areas: a, then b, then c.
  - **900–1599px:** 2 columns, `minmax(0,1.45fr) minmax(320px,1fr)`, areas `"a b" "a c"`. Gap 64px, padding 48px.
  - **1600–2199px:** 3 columns, `minmax(0,1.35fr) minmax(0,1fr) minmax(320px,0.85fr)`, areas `"a b c"`. Gap 72px, padding 64px.
  - **2200px and up:** the same 3 columns, **capped at max-width 2240px and centred**. Gap 96px, padding 80px. Extra space stays calm, or is offered to a second pane (§18).
- **The headline scales with the screen:** `clamp(56px, 3.4vw, 80px)`.
- **Body text keeps a readable line length:** never more than about 75 characters. If a column would get wider, add a column instead.

### Today, by area
- **a: the day.** Eyebrow, greeting, a quiet counts line (emails to sort · things to do · events tomorrow), **What next** (§16), then the **Today** fold.
- **b: Coming into view.** The "something shared" line (§17), then Deadlines.
- **c: the quiet things.** Spaces kept close (two columns of numeral + name, then "All 34 Spaces →"), Notepad, and **A reading** (the I Ching reading and the spirit card, folded by default).
- **In 3-column layouts,** b and c start level with What next (they sit below the greeting), not at the very top.

### Apply the same grid to other pages
- **Mail, Goals, Space:** main list in a (spanning a+b when there are 3 columns), side panels in c.
- **Notes / Tables:** one reading column at most 760px wide, with the list in c.

### Remove from the current build
- **The sub-header bar** with the boxed ← back arrow and "+ New". Keep **a slim, unboxed breadcrumb line** instead (see below). Set something down replaces "+ New".

### Breadcrumb (decided)
- **A slim line** at the top of the page container, above the page eyebrow: Jost 14, muted segments, a `/` separator in `--k-line`, and the current segment in ink. No box, no arrow, no bar background, and no keyline of its own.
- **The path starts at the group, not "Home":** `Conversations / Mail / Ana Ribeiro – Class on Saturday`. The wordmark is home.
- **Every segment except the last is a link.** Esc, or ⌘[, goes up one level.
- **Hide it at the top level of a tool** (e.g. just Mail): the page title already says where you are. It appears once you're deeper than that.
- **Long titles truncate** with an ellipsis, middle segments first. Never wrap.
- **On mobile:** show the parent segment only ("‹ Mail"), as text, 44px tall.
- **"€0 spent this month"** and any other money figure on Today (§17: money is optional and never pushed).
- **Red left bars, red text and target icons on deadlines.** Late items show "14 days late" in `--k-goldt` (Jost 500, 13px). Upcoming items are muted.
- **The spirit card's box, sparkle icon and ×.** It becomes a quiet entry inside "A reading".
- **The full-width green Set something down bar.** It should be the small folded tab (§15).

## 20. Notepad – a popover, not a section (V12)

Reference: `Koyeba Notepad.dc.html`. **Remove the Notepad section from Today.** The Notepad becomes a popover you open, write in and close.

### What it is (and isn't)
- **Set something down** files things: it classifies and sends them to the right tool.
- **Notepad** just keeps things: **one running page per person, never sorted, never tidied**, always exactly as left.

### Trigger
- **Desktop:** fixed at bottom-left (left 32px, bottom 24px), level with the Set down tab at the centre. "*Notepad*" in Cormorant italic 20, then a muted count of open lines. `--k-bg` ground, padding 9px 16px, 1px `--k-line` border (`--k-gold` while open).
- **Shortcut ⌘;** toggles it from anywhere.
- **Mobile:** "Notepad" sits at the top of Contents, above Kept close, and opens full screen.

### Popover
- **Placement:** rises from the trigger (left 32px, bottom 76px). Width min(440px, 100% − 64px), `max-height: calc(100vh − 100px)`, flex column, `--k-panel` ground, 1px keyline, square corners, no shadow. Fades up 8px over .4s.
- **Header:** "Notepad" (Cormorant 30), "Kept · just now" (muted 12.5px), and "Close · Esc" on the right. The header always stays visible; the list scrolls (`flex:1; min-height:0; overflow:auto`).
- **Lines:** each line is an **auto-growing textarea** (`rows=1`, `resize:none`, `overflow:hidden`, `box-sizing:border-box`, height set to scrollHeight on input). Cormorant 300, 21px/1.35, padding 10px 0, with a 1px keyline under each, like lined paper. **Long lines wrap; never clip.**
- **Keys:**
  - ↵ starts a new line below.
  - Backspace on an empty line removes it and moves up.
  - ↑ at the start of a line, or ↓ at the end, moves between lines.
  - Esc, or clicking outside, closes it.
- **Saving:** **autosave** on every change (debounced), per user, synced. Opening it focuses the last, empty line ("Write anything…").
- **Sending a line on:** on the focused, non-empty line, show "**Set down →**" (gold, Jost 500, 12.5px) on the right.
  - Clicking it hands the text to **Set something down** (§15), which classifies it as usual.
  - The line then stays in the notepad **struck through and muted**, with "→ a task" (or event, note…) in gold. **It's never deleted.**
  - A forest confirmation appears with **Undo**, which unstrikes the line and removes the created item.
- **Footer:** muted 12.5px: "Never sorted, never tidied. ↵ for a new line. Send any line on with 'Set down →'."

### Don't
- No Notepad section on Today.
- No titles, folders or formatting toolbar.
- No auto-sorting of notepad lines.

## 21. Notes (V14)

Reference: `Koyeba Notes.dc.html` (click a note to open it). **This replaces the six-across card grid and the current note page.**

**Index**
- Title block: "Notes", then an italic line naming the note you were last in.
- One line holds the search ("Search notes – titles, words, links"), Recent · By Space · A – Z, and a gold "New note" button.
- **Notes are grouped** (Today / This week / Earlier in October, or by Space). Each group folds. Use two columns of rows on wide screens.
- **Each row:** the title in Cormorant 24 (one line), the Space in gold, the first line of the note in muted text, and the date.
- **Side column:** Kept close, and By Space with counts (click a Space to filter).

**A note**
- A slim breadcrumb, then the title in Cormorant up to 80px, then meta: the Space (gold) · edited · word count.
- **No inset box. The reading column is at most 760px.** Body text is Jost 17.5/1.75.
- **Headings** are Cormorant 32 with a keyline beneath and **fold** (−/+, with a count shown when closed). No ▼ arrows and no bold gold sans.
- **Plain links** are one row each: the link's own title, then "domain →" in gold. **No boxed preview cards.**
- **A rich preview** appears only when the page has a real image and description: the title, description and "domain →" between keylines, with the page's og:image at 150×100. **Never fall back to the Koyeba logo.**
- **Right column:**
  - At the top: Kept close (gold square), Share and ···.
  - Folding sections: **In Spaces** (+ Add to another Space), **Also findable as** (words in italic, + Add a word), **Linked** (tasks, emails, files, with "+ Task · File · Scan · Link"), and **Shared with**.
  - "Delete this note" as a muted line at the bottom.
- **Remove:** the icon toolbar (star, avatar, image, paperclip, bin), the coloured Space chips, the "Add Space" dropdown, the search-term input box, and the boxed "Linked & attached" buttons with emoji.

## 22. Tasks (V14)

Reference: `Koyeba Tasks.dc.html`. **This replaces the endless single list and the form-like task page.**

**Index**
- Title block plus an italic line built from live data ("Four things come first. Start with '…'.").
- **Two orders, remembered per person:**
  - **By priority (default):** piles First · Soon · Whenever · Done. Tasks are grouped by Space inside a pile, and long piles end with "And 180 more, across other Spaces".
  - **By date:** Now (late and today) · This week · Later · Someday · Done.
- **Quick add line** at the top of the list. In priority order, its placeholder is "Add something to First…" and the task goes into the open pile.
- **Row:** a 13px square to tick (it fills gold, with "Done. Nicely." and Undo), the title, then the Space (gold) · duration · status. The due date sits on the right; **late dates** are gold, Jost 500.
- **Side:** By Space, and Waiting on someone.

**A task**
- A slim breadcrumb, then a 28px square to tick and the title in Cormorant up to 72px.
- **The properties are a sentence, not a form:** "Due *Friday 30 October*, *doesn't repeat*. Remind me *the morning of*. Takes *about 2 hours*, *first priority*, *not started*." Each value has a dotted gold underline and changes when clicked (a small popover in the real build). **No dropdowns.**
- **Steps** (a folding checklist with "2 of 4" and "+ Add a step"), then **Notes**.
- **Right column:**
  - Kept close · Assign · Share · ···.
  - Folding sections: **In Spaces**, **Linked**, **Also findable as**, and **Who can see this** ("Only you" + Share).
  - "Delete this task" at the bottom.
- **Remove:** the boxed P1 / duration / status dropdowns, the coloured Space chips, the calendar emoji, the boxed panels and the emoji button row.

## 23. Reflection (V14)

Reference: `Koyeba Reflection.dc.html` (open Spirit cards, I Ching, Compass and Horoscope from the practices list).

- **Main Reflection page:**
  - A title and an italic line ("You last wrote three days ago – you said you were tired."). **No stat boxes and no icon tile grid.**
  - **Lately:** all entries as rows, with the kind (uppercase gold) · the text (journal entries and dreams in italic, I Ching questions under the reading) · when. Filters: All · Journal · Dreams · Cards · I Ching.
  - **Side:** today's card, then the **practices** as a numbered list with live hints (I Journal … VIII Insights).
- **Spirit cards:**
  - **The back:** forest, with a gold double keyline and the ivory Mandombe "ko". Draw another deals it face down ("Tap to turn"). Only the back, or "Turn over", flips it (rotateY, .9s).
  - **The face:** ivory, with the numeral, the name in Cormorant 38, a gold rule and the line in italic.
  - **The art is generated, not illustrated.** It's a gold horizon line, one or two fine gold circles (sometimes with a 14–22% gold wash), and the card's initial in large gold Cormorant italic. Pick one of five fixed compositions from a hash of the card name, so each card always looks the same. **No emoji, no clip art, and no stock images.**
  - **History:** a wrapping row of small ivory cards (numeral + name), then rows with date · name · line.
- **I Ching:**
  - The question goes on an underline, with a gold "Cast the coins" button.
  - The result shows six drawn lines, solid or broken, with the changing line in gold, beside the character, name, subtitle and reading.
  - Past readings are rows: date · character (no wrap) · name → name · the question in italic.
- **Compass:**
  - The decision on an underline. Option A and B, each with a name and "The real case for it…" on lined paper.
  - Then a sentence to click through: "It *can be undone*, it belongs to *Business*, and it matters *this year*."
  - "Find my bearing" gives "The weight leans towards *A*." with three lenses (Regret, Undoing, Your own words).
- **Horoscope:** a page, **not a modal**. Sun / Moon / Rising as words in Cormorant (**no zodiac emoji**), a one-line character sketch, today's reading, and "Edit birth details".

---

## Files in this bundle
- `Koyeba App.dc.html`: the full interactive prototype, covering every screen above.
- `Koyeba Logo.dc.html`: the Mandombe logo explorations, 2a–2f.
- `Koyeba Brand Pack.dc.html`: the brand rules (logo, colour, type, voice, do's and don'ts).
- `Koyeba Business Card.dc.html`: the business card (3a is the chosen direction).
- `Koyeba Website.dc.html`: the public homepage for koyeba.co (see §10).
- `Koyeba Mail.dc.html`: the Mail page (see §12).
- `Koyeba Goals.dc.html`: the Goals page (see §13).
- `Koyeba Navigation.dc.html`: the new groups and navigation, desktop and mobile (see §17).
- `Koyeba Side by Side.dc.html` and `Koyeba Side by Side Mobile.dc.html`: two panes and pairs (see §18).
- `Koyeba Wide Screens.dc.html`: the responsive page grid (see §19).
- `Koyeba Notepad.dc.html`: the Notepad popover (see §20).
- `Koyeba Notes.dc.html`, `Koyeba Tasks.dc.html`, `Koyeba Reflection.dc.html`: see §21–23.
- `Koyeba Set Down.dc.html`: the smart Set something down drawer and What next (see §15–16).
- `Koyeba Night Mode.dc.html`: night tokens, fixes and a reference screen (see §14).
- `Koyeba Space.dc.html`: the Space page (see §11). `assets/art-cover.png` is sample content only.
- `email-signature.html`: a ready-to-paste email signature.
- `support.js`: the runtime needed only to open the prototypes locally.
- `fonts/`: Cormorant Garamond and Jost, woff2.
- `assets/`: the Mandombe SVGs.
